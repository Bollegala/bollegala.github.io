Iris dataset can be downloaded from here.
https://archive.ics.uci.edu/ml/datasets/Iris

I have already collapsed iris-versicolour and iris-virginica into class 0
and iris-setosa to class 1.

train.data contains 650 instances and test.data contains 100 instances.

In order to correctly train with tanh activation we must initialize the
neural network such that the weights are not in the saturated reigons.
This can be done as described in "Efficient backprop" by LeCun (the paper can
be found in the directory).

Specifically, all weights must be sampled from a zero mean Gaussian with
standard deviation set to the inverse square root of the fan-in number of
the corresponding neuron.

Centralization must be performed on the train/test instances.