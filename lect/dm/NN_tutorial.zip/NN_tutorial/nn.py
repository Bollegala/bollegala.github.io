import numpy
#numpy.random.RandomState = 10

D = 4
M = 2

def load_data(fname):
    L = []
    with open(fname) as F:
        for line in F:
            p = line.strip().split(",")
            x = numpy.zeros(D)
            for i in range(D):
                x[i] = float(p[i])
            L.append((x, int(p[D])))
    return L


def centralization(train_data, test_data):
    X = numpy.zeros((len(train_data) + len(test_data), D))
    c = 0
    for i in range(0, len(train_data)):
        X[c,:] = train_data[i][0]
        c += 1
    for i in range(0, len(test_data)):
        X[c,:] = test_data[i][0]
    mean = numpy.mean(X, axis=0)
    sd = numpy.std(X, axis=0)
    norm_train = []
    for (x, t) in train_data:
        for i in range(0, D):
            x[i] = (x[i] - mean[i]) / sd[i]
        norm_train.append((x, t))
    norm_test = []
    for (x, t) in test_data:
        for i in range(0, D):
            x[i] = (x[i] - mean[i]) / sd[i]
        norm_test.append((x, t))
    return norm_train, norm_test


def train():
    train_data = load_data("train.data")
    print "Total no of train instances =", len(train_data)
    a = numpy.zeros(M) 
    W = numpy.random.normal(loc=0.0, scale=1.0 / numpy.sqrt(D), size=(M, D))
    u = numpy.random.normal(loc=0.0, scale=1.0 / numpy.sqrt(M), size=(M))
    test_data = load_data("test.data")
    train_data, test_data = centralization(train_data, test_data)
    T = 100
    for k in range(0, T):
        eta = 0.0001 / (1.0 + k)
        for (x, t) in train_data:
            t = 2 * t - 1
            # Forward propagation
            a = numpy.dot(W, x)
            z = h(a)
            y = numpy.dot(z, u)
            delta_out = y - t
            # Backward propagation
            u -= eta * delta_out * z
            delta = h_prime(a) * u * delta_out
            for i in range(M):
                for j in range(D):
                    W[i,j] -= eta * delta[i] * x[j]
        print "Itr = %d, Train Accuracy = %f, Test Accuracy = %f" % (k, evaluate(train_data, W, u), evaluate(test_data, W, u))
    pass


def evaluate(test_data, W, u):
    corrects = 0
    total = 0
    for (x, t) in test_data:
        t = 2 * t - 1
        total += 1
        a = numpy.dot(W, x)
        z = h(a)
        y = numpy.dot(z, u)
        y = h(y)
        if (y * t) > 0:
            corrects += 1
    return float(100 * corrects) / float(total)


def h(x):
    return 1.7159 * numpy.tanh((2.0 * x / 3.0))


def h_prime(x):
    return (1.7159 * 2.0/ 3.0) * (1 - (h(2.0 * x / 3.0) ** 2))



def process():
    train()
    pass


if __name__ == "__main__":
    process()

