"""
This program reads a text file and compute the word co-occurrences using PMI.
Each line of the text file is considered as a different sentence, and we
will consider two words u and v to be co-occurring if they appear in the 
same sentence. We will then compute the co-occurrence table as we learnt
in the lecture, from which we will compute PMI.

Tasks:
1) Modify this script and implement the Chi-squared word association measure.
2) Modify this script and implement the Log-Likelihood Ratio (LLR) word association measure
"""

import math


def build_cooc_table(fname):
    T = {}
    freq = {}
    N = 0
    with open(fname) as corpus:
        for line in corpus:
            N += 1
            tokens = list(set(line.strip().split()))
            for token in tokens:
                freq[token] = freq.get(token, 0) + 1
            for i in range(0, len(tokens)):
                for j in range(i+1, len(tokens)):
                    (first, second) = (tokens[i], tokens[j])
                    T[(first, second)] = T.get((first, second), 0) + 1
    return (T, freq, N)


def compute_pmi(T, freq, N):
    P = {}
    for (first, second) in T:
        if T[(first, second)] > 0:
            P[(first, second)] = get_pmi(T[(first, second)], freq[first], freq[second], N)
    return P


def get_pmi(joint_count, first_count, second_count, N):
    val = float(joint_count * N) / float(first_count * second_count)
    joint_prob = float(joint_count) / float(N)
    return joint_prob * math.log(val)


def main():
    (T, freq, N) = build_cooc_table("corpus.txt")
    pmi_values = compute_pmi(T, freq, N)
    # sort word pairs according to their pmi values and show the top k
    k = 50
    L = pmi_values.items()
    L.sort(lambda x, y: -1 if x[1] > y[1] else 1)
    for i in range(0, k):
        ((first, second), val) = L[i]
        print "%d: %s %s = %f" % (i, first, second, val)
    pass


if __name__ == "__main__":
    main()
    pass
