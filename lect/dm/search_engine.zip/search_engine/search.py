"""
This program shows how to build a simple inverted index from a collection of documents
and perform AND (conjunctive) queries.

Danushka Bollegala
COMP 527 Data Mining
"""

import glob
import sys
import os
import codecs
from collections import defaultdict

def get_files(dir_path):
    """
    Specify the root directory path that contains the files to be indexed.
    We will use the files that are in the directories under the dir_path.
    """
    files = []
    for directory in glob.glob("%s/*" % dir_path):
        if os.path.isdir(directory):
            for file in glob.glob("%s/*" % directory):
                if os.path.isfile(file):
                    files.append(file)

    print("Total files found for indexing = %d" % len(files))
    return files


def build_index(files):
    """
    Builds an inverted index from words to file ids.
    A mapping from file names to ids is also returned
    """
    fmap = defaultdict(lambda: len(fmap)) # file names to integer ids map
    h = {} # inverted index

    for file in files:
        fid = fmap[file]
        print("Indexing file: %s" % file)
        with codecs.open(file, "r", encoding="utf-8", errors="ignore") as F:
            for token in F.read().split():
                h.setdefault(token, []).append(fid)

    # sort the posting lists
    for token in h:
        h[token] = list(set(h[token]))
        h[token].sort()

    return h, fmap


def get_results(query, index, rev_fmap):
    """
    Given a two word query we will find the search results for their AND.
    """
    first, second = query.split()
    if not first in index:
        return []
    if not second in index:
        return []
    first_posting = index[first]
    second_posting = index[second]

    # Lets use first to be the query for the shorter posting list.
    if len(first_posting) > len(second_posting):
        first, second = second, first
        first_posting[:], second_posting[:] = second_posting[:], first_posting[:]

    #print(first, first_posting)
    #print(second, second_posting)
    results = []
    i = j = 0
    while i < len(first_posting) and j < len(second_posting):
        #print(i,j)
        if first_posting[i] == second_posting[j]:
            results.append(rev_fmap[first_posting[i]])
            i += 1
            j += 1
        elif first_posting[i] > second_posting[j]:
            j += 1
        else:
            i += 1
    return results


def main():
    files = get_files("./20newsgroups")
    index, fmap = build_index(files)

    # we need a mapping from file ids to file names    
    rev_fmap = {}
    for key, value in fmap.items():
        rev_fmap[value] = key

    while True:
        print("Enter query: ")
        query = sys.stdin.readline().strip()
        print(get_results(query, index, rev_fmap))        
    pass


if __name__ == '__main__':
    main()

